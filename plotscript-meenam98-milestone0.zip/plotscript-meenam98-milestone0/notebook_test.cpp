#include <QTest>

class NotebookTest : public QObject {
  Q_OBJECT

private slots:

  void initTestCase();

  // TODO: implement additional tests here
  

};

void NotebookTest::initTestCase(){

}


QTEST_MAIN(NotebookTest)
#include "notebook_test.moc"
